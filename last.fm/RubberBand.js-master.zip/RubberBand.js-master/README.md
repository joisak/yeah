RubberBand.js
=============

Easily add the iOS style pull-to-refresh functionality to any page. iOS users have become accustomed to being able to pull-to-refresh the content they're viewing. RubberBand allows you to add this functionality with a native feel.

http://thrivingkings.com/read/RubberBand-Easily-add-the-iOS-style-pull-to-refresh-functionality-to-any-page
